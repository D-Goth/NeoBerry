// Fichier généré automatiquement par le scan
const pairedDevices = [
  {
    "name": "Bose QC35",
    "mac": "AA:BB:CC:DD:EE:01",
    "connected": false
  },
  {
    "name": "Nintendo Switch",
    "mac": "AA:BB:CC:DD:EE:02",
    "connected": false
  },
  {
    "name": "Xiaomi Speaker",
    "mac": "AA:BB:CC:DD:EE:03",
    "connected": false
  }
];
export default pairedDevices;
